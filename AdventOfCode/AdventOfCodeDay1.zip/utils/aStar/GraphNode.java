package utils.aStar;

public interface GraphNode {
    String getId();
}