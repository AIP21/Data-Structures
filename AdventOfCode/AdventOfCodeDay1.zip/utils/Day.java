import utils.*;

public class Day extends AbstractDay {
    public static void main(String[] args) {
        new Day();
    }

    public Day() {
        super(false, 2023);
    }

    @Override
    public void part1() {
        
    }

    @Override
    public void part2() {

    }
}